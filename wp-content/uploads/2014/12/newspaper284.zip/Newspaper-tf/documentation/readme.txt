Please go to: 

http://forum.tagdiv.com/newspaper-documentation/


the support forum is here: 
http://forum.tagdiv.com/