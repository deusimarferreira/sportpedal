to use the child theme:

1. upload the main theme first
2. upload the child theme

will write better doc soon.